#define VERSION "3proxy-0.8.6"
#define BUILDDATE "160307165135"
